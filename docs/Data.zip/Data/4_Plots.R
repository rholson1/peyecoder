

# Load Data ---------------------------------------------------------------

setwd("~/Box Sync/peyeCoder/Data/")
d = read.csv("CueCue_101_CombinedData.csv")
d = d %>% select(-X)

timing = read_csv('CueCue_TeachingVideos_SegmentTiming_Key.csv')


# Cleaning ----------------------------------------------------------------

# identify what percentage of frames have an accuracy of NA during the critical window (300 to 1800 ms after the onset of the critical word)
# trials with more than 50% missing frames will be excluded from plots (and would be excluded from analyses)

cleaning = d %>%
  filter(TimeC >= 300 & TimeC <= 1800) %>% # select time window & max missing frames
  group_by(Source, Sub.Num, Tr.Num) %>% 
  summarise(
    maxN=length(Accuracy),
    lostN = sum(is.na(Accuracy)),
    percentMissingFrames = round((lostN/maxN),digits=4)*100) %>% 
  select(Source,Sub.Num,Tr.Num,percentMissingFrames)

d <- left_join(d,cleaning)
remove(cleaning)


# Trial N -----------------------------------------------------------------


plot <- d %>% 
  filter(TimeC==0 & Condition %in% c("Gaze","ME","GazeME")) %>%
  group_by(Sub.Num,Phase,Condition,Block,Source) %>% 
  summarise(N=sum(!is.na(percentMissingFrames[percentMissingFrames<50]))) %>%
  mutate(NeedToExclude = ifelse(N<2,'yes','no'))


ggplot(plot[plot$Phase=='Teaching',],aes(x=Sub.Num,y=N,fill=NeedToExclude)) +
  geom_bar(stat='identity')+
  theme_bw(base_size=12) +
  coord_cartesian(ylim=c(0,4.2),xlim=c(100,102),expand=F) +
  scale_y_continuous(breaks=seq(from=1,to=6,by=1)) +
  scale_x_continuous(breaks=unique(d$Sub.Num))+
  scale_fill_manual(values=c("gray","coral2")) +
  labs(x='Subject',y='Useable Trials (max 4)',title='Teaching') +
  facet_wrap(Source~Condition,ncol=6) +
  theme(legend.position="none",plot.title=element_text(hjust=.5),axis.text.x = element_text(angle = 90, vjust = 0.5)) 

ggplot(plot[plot$Phase=='Testing',],aes(x=Sub.Num,y=N,fill=NeedToExclude)) +
  geom_bar(stat='identity')+
  theme_bw(base_size=12) +
  coord_cartesian(ylim=c(0,6.2),xlim=c(100,102),expand=F) +
  scale_y_continuous(breaks=seq(from=1,to=6,by=1)) +
  scale_x_continuous(breaks=unique(d$Sub.Num))+
  scale_fill_manual(values=c("gray","coral2")) +
  labs(x='Subject',y='Useable Trials (max 4)',title='Testing') +
  facet_wrap(Source~Condition,ncol=6) +
  theme(legend.position="none",plot.title=element_text(hjust=.5),axis.text.x = element_text(angle = 90, vjust = 0.5)) 


# Teaching Time Course ----------------------------------------------------


plot = d %>% 
  filter(Phase=='Teaching' & Condition %in% c("Gaze","ME","GazeME") & percentMissingFrames < 50) %>%
  mutate(
    TargetAcc = ifelse(Accuracy==1,1, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,0,NA))),
    DistractorAcc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,1,ifelse(Accuracy==.5,0,NA))),
    FaceAcc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,1,NA)))
  ) %>% 
  gather(TargetAcc,DistractorAcc,FaceAcc,key='Region',value='Acc') %>%
  group_by(Sub.Num,Time,Region,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )

plot$Region = str_replace(plot$Region,'Acc','')

ggplot(plot,aes(x=Time,y=Acc,fill=Region,color=Region)) +
  coord_cartesian(xlim=c(-10,timing$End+10),ylim=c(0,1.10),expand=F) +
  scale_x_continuous(breaks=seq(from=0,to=10000,by=1000))+
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1))+
  scale_fill_manual(values=c("brown","orange","purple")) + 
  scale_color_manual(values=c("brown","orange","purple")) + 
  # Looks
  geom_vline(xintercept=timing$Looks,linetype='dashed',color='darkgrey')+
  annotate('text',x=(timing$Looks+timing$Carrier)/2,y=1.05,label='Speaker looks\nat each object')+
  # Carrier
  geom_vline(xintercept=timing$Carrier,linetype='dashed',color='darkgrey')+
  annotate('text',x=(timing$Carrier+timing$Target)/2,y=1.05,label='Carrier\nPhrase')+
  # Target
  geom_vline(xintercept=timing$Target,linetype='dashed',color='darkgrey')+
  geom_vline(xintercept=timing$Silence,linetype='dashed',color='darkgrey')+
  annotate('text',x=(timing$Target+timing$Silence)/2,y=1.05,label='Target\nWord')+
  geom_smooth(aes(ymin=lower, ymax=upper), stat="identity") +
  geom_line() +
  theme_bw(base_size=14) +
  labs(x='Time (in ms)',y='Proportion of Fixations') +
  theme( 
    plot.title=element_text(hjust=.5),
    legend.justification=c(1,1),
    legend.position=c(1,1),
    legend.background=element_rect(fill= NA, color=NA)) +
  facet_wrap(~Source,ncol=1)

setwd("~/Box Sync/peyeCoder/Data/plots/")
ggsave("CueCue_1_Teaching_TimeCourse.pdf",width=11,height=8)


# Teaching - Proportions --------------------------------------------------


plot = d %>% 
  filter(Phase=='Teaching' & Condition != 'Familiar' & percentMissingFrames < 50 & TimeC >= 300 & TimeC <= 1800) %>%
  mutate(
    TargetAcc = ifelse(Accuracy==1,1, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,0,NA))),
    DistractorAcc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,1,ifelse(Accuracy==.5,0,NA))),
    FaceAcc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,1,NA)))
  ) %>% 
  gather(TargetAcc,DistractorAcc,FaceAcc,key='Region',value='Acc') %>%
  group_by(Sub.Num,Tr.Num,Condition,Region,Source) %>%
  summarise(Acc = mean(Acc,na.rm=T)) %>% 
  group_by(Sub.Num,Condition,Region,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )

plot$Region = str_replace(plot$Region,'Acc','')

plot$Condition = factor(plot$Condition,c("Gaze","ME","GazeME"))


ggplot(plot,aes(x=Condition, y=Acc,fill=Region))+
  geom_bar(stat='identity')+
  # geom_point(shape=16,fill='black',colour='black',size=2)+
  # geom_point(data=bySub, aes(y=N),stat='identity',colour='gray', position=position_jitter(width = .3,height=0))+
  # geom_errorbar(width=.2, aes(ymin=lower, ymax=upper),color='black') +
  theme_bw(base_size=16) +
  coord_cartesian(xlim=c(0.5,3.5),ylim=c(-0.01,1.01),expand=F) +
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1)) +
  # scale_x_discrete(breaks=seq(from=1,to=3,by=1))+
  scale_fill_manual(values=c("brown","orange","purple")) + 
  # scale_color_manual(values=c('coral2','forest green','dodgerblue'))+
  labs(x='Condition',y='Proportion of Fixations') +
  theme(plot.margin=unit(c(1,1,1,1),"lines"),panel.grid.minor=element_blank()) +
  facet_wrap(~Source)

ggsave("CueCue_2_Teaching_Proportions.pdf",width=8,height=6)



# Teaching - Target Proportions -------------------------------------------

byTrial = d %>% 
  filter(Phase=='Teaching' & Condition != 'Familiar' & percentMissingFrames < 50 & TimeC >= 300 & TimeC <= 1800) %>%
  mutate(Acc = ifelse(Accuracy==1,1, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,0,NA)))) %>% 
  group_by(Sub.Num,Tr.Num,Condition,Source) %>%
  summarise(Acc = mean(Acc,na.rm=T)) 

bySub = byTrial %>% 
  group_by(Sub.Num,Condition,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )


# byGroup = bySub %>% 
#   group_by(Condition,Source) %>%
#   summarise(
#     N = sum(!is.na(Acc)),
#     SD = sd(Acc,na.rm=T),
#     SE = SD/sqrt(N),
#     Acc = mean(Acc,na.rm=T),
#     lower = Acc-SE,
#     upper = Acc+SE
#   )

byTrial$Condition = factor(byTrial$Condition,c("Gaze","ME","GazeME"))
bySub$Condition = factor(bySub$Condition,c("Gaze","ME","GazeME"))
# byGroup$Condition = factor(byGroup$Condition,c("Gaze","ME","GazeME"))


ggplot(bySub,aes(x=Condition,y=Acc,fill=Condition,color=Condition)) +
  geom_violin(data=byTrial,alpha=.8)+
  geom_point(shape=16,fill='black',colour='black',size=2)+
  # geom_point(data=bySub, aes(y=N),stat='identity',colour='gray', position=position_jitter(width = .3,height=0))+
  geom_errorbar(width=.2, aes(ymin=lower, ymax=upper),color='black') +
  theme_bw(base_size=16) +
  coord_cartesian(xlim=c(0.5,3.5),ylim=c(-0.01,1.01),expand=F) +
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1)) +
  # scale_x_discrete(breaks=seq(from=1,to=3,by=1))+
  scale_fill_manual(values=c('coral2','forest green','dodgerblue'))+
  scale_color_manual(values=c('coral2','forest green','dodgerblue'))+
  labs(x='Condition',y='Proportion of Target Fixations') +
  theme(plot.margin=unit(c(1,1,1,1),"lines"), legend.position="none",panel.grid.minor=element_blank()) +
  facet_wrap(~Source)

ggsave("CueCue_3_Teaching_TargetAcc.pdf",width=8,height=6)


# Teaching - Face Proportions ---------------------------------------------


byTrial = d %>% 
  filter(Phase=='Teaching' & Condition != 'Familiar' & percentMissingFrames < 50 & TimeC >= 300 & TimeC <= 1800) %>%
  mutate(Acc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,1,NA)))) %>% 
  group_by(Sub.Num,Tr.Num,Condition,Source) %>%
  summarise(Acc = mean(Acc,na.rm=T)) 

bySub = byTrial %>% 
  group_by(Sub.Num,Condition,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )

byTrial$Condition = factor(byTrial$Condition,c("Gaze","ME","GazeME"))
bySub$Condition = factor(bySub$Condition,c("Gaze","ME","GazeME"))

ggplot(bySub,aes(x=Condition,y=Acc,fill=Condition,color=Condition)) +
  geom_violin(data=byTrial,alpha=.8)+
  geom_point(shape=16,fill='black',colour='black',size=2)+
  # geom_point(data=bySub, aes(y=N),stat='identity',colour='gray', position=position_jitter(width = .3,height=0))+
  geom_errorbar(width=.2, aes(ymin=lower, ymax=upper),color='black') +
  theme_bw(base_size=16) +
  coord_cartesian(xlim=c(0.5,3.5),ylim=c(-0.01,1.01),expand=F) +
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1)) +
  # scale_x_discrete(breaks=seq(from=1,to=3,by=1))+
  scale_fill_manual(values=c('coral2','forest green','dodgerblue'))+
  scale_color_manual(values=c('coral2','forest green','dodgerblue'))+
  labs(x='Condition',y='Proportion of Face Fixations') +
  theme(plot.margin=unit(c(1,1,1,1),"lines"), legend.position="none",panel.grid.minor=element_blank()) +
  facet_wrap(~Source)



# Teaching - Distractor Proportions ---------------------------------------

byTrial = d1 %>% 
  filter(Phase=='Teaching' & Condition != 'Familiar' & percentMissingFrames < 50 & TimeC >= 300 & TimeC <= 1800) %>%
  mutate(Acc = ifelse(Accuracy==1,0, ifelse(Accuracy==0,1,ifelse(Accuracy==.5,0,NA)))) %>% 
  group_by(Sub.Num,Tr.Num,Condition,Source) %>%
  summarise(Acc = mean(Acc,na.rm=T)) 

bySub = byTrial %>% 
  group_by(Sub.Num,Condition,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )

byTrial$Condition = factor(byTrial$Condition,c("Gaze","ME","GazeME"))
bySub$Condition = factor(bySub$Condition,c("Gaze","ME","GazeME"))


ggplot(bySub,aes(x=Condition,y=Acc,fill=Condition,color=Condition)) +
  geom_violin(data=byTrial,alpha=.8)+
  geom_point(shape=16,fill='black',colour='black',size=2)+
  # geom_point(data=bySub, aes(y=N),stat='identity',colour='gray', position=position_jitter(width = .3,height=0))+
  geom_errorbar(width=.2, aes(ymin=lower, ymax=upper),color='black') +
  theme_bw(base_size=16) +
  coord_cartesian(xlim=c(0.5,3.5),ylim=c(-0.01,1.01),expand=F) +
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1)) +
  # scale_x_discrete(breaks=seq(from=1,to=3,by=1))+
  scale_fill_manual(values=c('coral2','forest green','dodgerblue'))+
  scale_color_manual(values=c('coral2','forest green','dodgerblue'))+
  labs(x='Condition',y='Proportion of Distractor Fixations') +
  theme(plot.margin=unit(c(1,1,1,1),"lines"), legend.position="none",panel.grid.minor=element_blank()) + 
  facet_wrap(~Source)


# Test - Time Course ------------------------------------------------------


plot = d %>% 
  filter(Phase=='Testing' & Condition %in% c("Gaze","ME","GazeME") & percentMissingFrames < 50 & TimeC >= -300 & TimeC <= 1800) %>%
  mutate(Acc = ifelse(Accuracy==1,1, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,0,NA)))) %>% 
  group_by(Sub.Num,TimeC,Condition,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )


plot$Condition = factor(plot$Condition,c("Gaze","ME","GazeME"))

ggplot(plot,aes(x=TimeC,y=Acc,fill=Condition,color=Condition)) +
  geom_hline(yintercept=0.5,linetype='dashed',color='black') +
  # geom_vline(xintercept=0,linetype='dashed',color='darkgrey')+
  coord_cartesian(xlim=c(0,1800),ylim=c(0,1),expand=F) +
  scale_x_continuous(breaks=seq(from=-300,to=1800,by=300))+
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1))+
  geom_smooth(aes(ymin=lower, ymax=upper), stat="identity") +
  geom_line() +
  theme_bw(base_size=14) +
  labs(x='Time (in ms)',y='Proportion of Target Fixations') +
  theme( 
    plot.title=element_text(hjust=.5),
    legend.justification=c(1,1),
    legend.position=c(1,1),
    legend.background=element_rect(fill= NA, color=NA)) +
  facet_wrap(~Source,ncol=1)



# Test - Target Proportions -----------------------------------------------


byTrial = d %>% 
  filter(Phase=='Testing' & Condition %in%c("Gaze","ME","GazeME") & percentMissingFrames < 50 & TimeC >= 300 & TimeC <= 1800) %>%
  mutate(Acc = ifelse(Accuracy==1,1, ifelse(Accuracy==0,0,ifelse(Accuracy==.5,0,NA)))) %>% 
  group_by(Sub.Num,Tr.Num,Condition,Source) %>%
  summarise(Acc = mean(Acc,na.rm=T)) 

bySub = byTrial %>% 
  group_by(Sub.Num,Condition,Source) %>%
  summarise(
    N = sum(!is.na(Acc)),
    SD = sd(Acc,na.rm=T),
    SE = SD/sqrt(N),
    Acc = mean(Acc,na.rm=T),
    lower = Acc-SE,
    upper = Acc+SE
  )

byTrial$Condition = factor(byTrial$Condition,c("Gaze","ME","GazeME"))
bySub$Condition = factor(bySub$Condition,c("Gaze","ME","GazeME"))

ggplot(bySub,aes(x=Condition,y=Acc,fill=Condition,color=Condition)) +
  geom_violin(data=byTrial,alpha=.8)+
  geom_hline(yintercept=0.5,linetype='dashed',color='black') +
  geom_point(shape=16,fill='black',colour='black',size=2)+
  # geom_point(data=bySub, aes(y=N),stat='identity',colour='gray', position=position_jitter(width = .3,height=0))+
  geom_errorbar(width=.2, aes(ymin=lower, ymax=upper),color='black') +
  theme_bw(base_size=16) +
  coord_cartesian(xlim=c(0.5,3.5),ylim=c(-0.01,1.01),expand=F) +
  scale_y_continuous(breaks=seq(from=0,to=1,by=.1)) +
  # scale_x_discrete(breaks=seq(from=1,to=3,by=1))+
  scale_fill_manual(values=c('coral2','forest green','dodgerblue'))+
  scale_color_manual(values=c('coral2','forest green','dodgerblue'))+
  labs(x='Condition',y='Proportion of Target Fixations') +
  theme(plot.margin=unit(c(1,1,1,1),"lines"), legend.position="none",panel.grid.minor=element_blank()) +
  facet_wrap(~Source)


