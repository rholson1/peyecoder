
library(tidyverse)

# Load LWL Data -----------------------------------------------------------

setwd('~/Box Sync/peyeCoder/Data/handcoded')

d.lwl = read.csv("CueCue_101_peyeData.csv",stringsAsFactors = F)

# create a column that specifies the target image; if the target side is left use the left image, otherwise use the right image
# do the opposite to specify the distractor image
d.lwl$Target.Image = ifelse(d.lwl$Target.Side=='L',d.lwl$Left.Image,d.lwl$Right.Image)
d.lwl$Distractor.Image = ifelse(d.lwl$Target.Side=='R',d.lwl$Left.Image,d.lwl$Right.Image)


# subset, reorder, and rename columns
d.lwl = d.lwl %>% select(Sub.Num,Trial.Order,Trial.Number,Condition,Target.Image,Distractor.Image,Target.Side,Time,Time.Centered,Response,Accuracy)
colnames(d.lwl) <- c("Sub.Num","Order","Tr.Num","Condition","Target","Distractor","TargetSide","Time","TimeC","AOI","Accuracy")

# from peyeCoder the Condition column includes information on both condition & phase (separated by a space), 
# split this into two columns titled Condition and Phase
d.lwl = d.lwl %>% separate(col=Condition,into=c("Condition","Phase"),sep=" ")  

# there are 3 blocks of trials: Block 1 (1-13), Block 2 (14-26), and Block 3 (27-38)
d.lwl$Block = ifelse(d.lwl$Tr.Num <=13, 1, ifelse(d.lwl$Tr.Num >13 & d.lwl$Tr.Num <26,2,3))

# the Order column contains the name of the study (i.e., CueCue-1), but we only need the number
# split the column to only use what comes after the -
d.lwl = d.lwl %>% separate(col=Order,into=c("Experiment","Order"),sep="-")
d.lwl = d.lwl %>% select(-Experiment)


# we skipped 18 frames, but coded from picture in picture onset
# this means that we started coding ~ 15 frames into the trial, which means Time=0 is NOT at the onset of the trial
# to adjust for this we need to add 500 ms (15*33.3333) to Time
d.lwl$Time = d.lwl$Time + 500

# we do NOT need to adjust TimeC, because the value we entered into our Trial Order (for CritOnset) 
# was based on the amount of time that elapses until the onset of the critical word, *FROM* when we started coding the trial

# convert accuracy from a character to numeric (this will convert offs and aways, which are . and - into NAs)
d.lwl$Accuracy <- as.numeric(d.lwl$Accuracy)

# change AOIs that are center to be face
d.lwl$AOI[d.lwl$AOI=='center']='face'

# change Gaze+ME to be GazeME to match tobii data
d.lwl$Condition[d.lwl$Condition=='Gaze+ME']='GazeME'


# round Time to remove decimals
d.lwl$Time = round(d.lwl$Time,digits=0)
d.lwl$TimeC = round(d.lwl$TimeC,digits=0)


# Load Raw Gaze Data ----------------------------------------------------------

setwd('~/Box Sync/peyeCoder/Data/tobii')
d.tobii = read.csv("CueCue_101_TobiiData.csv",stringsAsFactors = F)
d.tobii = d.tobii %>% select(-X)

# fix Phase to be capitalized like the handcoded data
d.tobii$Phase[d.tobii$Phase=='teaching']='Teaching'
d.tobii$Phase[d.tobii$Phase=='test']='Testing'

# fix Target.Side from Left to L and Right to R to match handcoded data
d.tobii$Target.Side[d.tobii$Target.Side=='Left']='L'
d.tobii$Target.Side[d.tobii$Target.Side=='Right']='R'

# fix Target and Distractor to be lower case to match handcoded data
d.tobii$Target = tolower(d.tobii$Target)
d.tobii$Distractor = tolower(d.tobii$Distractor)

# fix AOI to be lower case and replace NAs with "off"
d.tobii$AOI[is.na(d.tobii$AOI)]='off'
d.tobii$AOI = tolower(d.tobii$AOI)

# change accuracy to be 0.5, rather than NA, when children are fixating the speaker's face to match the handcoded data
d.tobii$Accuracy[d.tobii$AOI=='face']=0.5

# subset, reorder, and rename columns
d.tobii = d.tobii %>% select(Sub.Num,Order,Block,Tr.Num,Condition,Phase,Target,Distractor,Target.Side,TimeBin,Time,TimeC,AOI,Accuracy)
colnames(d.tobii) <- c("Sub.Num","Order","Block","Tr.Num","Condition","Phase","Target","Distractor","TargetSide","TimeBin","Time","TimeC","AOI","Accuracy")

# change formatting to match handcoded data
d.tobii$Order = as.character(d.tobii$Order)

# round Time to remove decimals
d.tobii$Time = round(d.tobii$Time,digits=0)
d.tobii$TimeC = round(d.tobii$TimeC,digits=0)


# Downsample Tobii --------------------------------------------------------

# our handcoded data is every 33 ms, but the tobii data is every 16 ms
# here we will downsample the tobii data, by binning every 33ms and calculating the average accuracy

# create a list of timeframes we want to bin by (here -5933 to 4000 in 33 ms increments)
TimeNew = c(floor(seq(from=-5933, to=0, by=(1000/30))),round(seq(from=0, to=3999, by=(1000/30)),digits=0))

# create a dataframe that contains the timeframes and sequentially number each timeframe (bin column)
new_time = data.frame(TimeNew=TimeNew,bin=1:length(TimeNew))
new_time$bin = as.numeric(new_time$bin)

# add a column in the dataframe that bins each time frame (using cut)
# increment the bins by 1 (this is to better align TimeC for each bin with the corresponding TimeNew value in new_time)
# add the new_time dataframe (using left_join)
# remove the bin (used to merge the two dataframes) and TimeC (the original time frames)
# and rename the new, binned timeframes to be TimeC
d.tobii = d.tobii %>% mutate(bin=cut(TimeC,breaks=new_time$TimeNew,labels=F)) %>% 
  mutate(bin = bin+1) %>% 
  left_join(new_time) %>% 
  select(-c(TimeC,bin)) %>% 
  rename(TimeC = TimeNew)

# now we have a dataframe that will increment time in 33, rather than 16 ms increments (for TimeC)
# this means that for each child there will usually be 2 datapoints for each time frame

# so in order to downsample, we need to decide what to do with multiple time frames

# one option is to average multiple datapoints for each timeframe
# NOTE: we can average Accuracy values within a bin, but not AOIs. how we resolve multiple AOIs will lead to some mismatches

# for instance, if the child is fixating the target on the first instance where TimeC=0, but fixating off on the second instance where TimeC=0...
# then accuracy = 1 (average of 1 and NA), 
# if we use the first AOI then it would be target; if we used the second AOI then it would be off

# conversely, if the child is fixating off on the first instance where TimeC=0, but fixating the target on the second instance...
# then accuracy = 1
# if we use the first AOI then it would be off; if we used the second AOI then it would be target

# so with either choice our AOI would be misaligned with the accuracy measure on 

# an alternative, which the script below uses, is to drop the second frame within each bin
# this creates the greatest parity when comparing handcoded and tobii data, because we have reduced the 
# sampling rate of the tobii to every 33 ms, by dropping timeframes that occured between each 33 ms increment


d.tobii = d.tobii %>% 
  group_by(Sub.Num,Order,Block,Tr.Num,Condition,Phase,Target,Distractor,TargetSide,TimeC) %>% 
  summarise(
    Time = first(Time),
    AOI = first(AOI),
    Accuracy = first(Accuracy)
  )


d.tobii$Block = as.numeric(d.tobii$Block)

# Merge and Export --------------------------------------------------------

d.lwl$Source = 'lwl'
d.tobii$Source = 'tobii'

d = bind_rows(d.lwl,d.tobii)

setwd("~/Box Sync/peyeCoder/Data/")
write.csv(d, file='CueCue_101_CombinedData.csv')
