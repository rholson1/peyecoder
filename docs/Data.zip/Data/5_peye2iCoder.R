
# path to folder containing the exported peyeCoder files
read_from = setwd("~/Box Sync/peyeCoder/Data/handcoded")

# list of all the exported peyeCoder data
identifier = "_wide.csv"

# path to folder where you should save the formeatted peyeCoder data
save_to = setwd("~/Box Sync/peyeCoder/Data/handcoded")


# Functions ---------------------------------------------------------------

calcRT = function(d,startWindow="F0",endWindow="F4700") {
  
  # determine which column correpsonds to the start window & end window
  startWindow <- which(names(d)==startWindow)
  endWindow <- which(names(d)==endWindow)
  
  # set RTs to NA
  d$FirstGap <- NA
  d$RT <- NA
  
  # determine the total number of trials (rows) for the participant
  endRows <- nrow(d)
  
  # for each trial...
  for (row in 1:endRows) {
    
    # we will calculate the duration of the first shift (# of frames)
    firstGap = NA
    # and document when that first shift was initiated (in ms since target word onset)
    RT = NA
    
    # subset to only include fixations between the start and end of the window for the current trial (row)
    fixations = d[row,startWindow:endWindow]
    
    # if the child does not complete a shift during the window,
    # i.e., they do not fixation both the target (1) and distractor (0)
    # then firstGap and RT will remain NA
    # if there is a shift, however, then calculate the RT (when the shift began) and firstGap (how many frames it took)
    
    if (0 %in% fixations & 1 %in% fixations) {
      
      # identify frame where the child first fixates either the distractor (0) or target (1) images
      # usually this is the first frame of the window (i.e., startWindow), unless the child is looking away
      firstFixLoc = min(c(which(fixations==0),which(fixations==1)))
      
      # identify whether the child first fixates either the distractor (0) or target (1)
      firstFix = as.numeric(fixations[firstFixLoc])
      
      # identify frame where the child first fixates the other image
      if (firstFix==1) {
        otherFixLoc = min(which(fixations==0))
      } else if (firstFix==0) {
        otherFixLoc = min(which(fixations==1))
      }
      
      # identify all frames where the child is fixating off (.) or away (-) from the images
      offs = sort(c(which(fixations=='.'),which(fixations=='-')))
      
      # remove off/away frames (if there are any) that occur *before* the child first fixated either the distractor or target images
      # this is because we calculate RT as the first shift from one image to another
      # if the child starts the window looking away, we do not want to identify the first shift from looking away to an image
      offs = offs[offs > firstFixLoc]
      
      # remove off/away frames (if there are any) that occur *after* the child first shifted to fixate the other image
      # this is because we calculate RT as the first shift from one image to another
      # if the child starts the window looking away, we do not want to identify the first shift from looking away to an image
      offs = offs[offs < otherFixLoc]
      
      # if the length of shift is only 1 frame, then set the value of firstGap to 1
      # otherwise calulate the number of consecutive off/away frames starting at the end of the arrray (offs)
      # this final gap is when the child first shifted to the new picture
      # there may be other gaps before this final gap (that we need to ignore in the array) 
      # which occur if the child had shifted away and back to the same image before shifting to the new image

      if(length(offs)==1){
        firstGap=1
        } else {
          for (i in (length(offs)-1):1) {
            if (offs[i]!=(offs[i+1]-1)){
              firstGap=length(offs)-i
              break
            }
            
            if (i==1) {
              firstGap=length(offs)
              }
          }
        }
      
      # calculate the RT, by determining the frame where the shift initiated
      # this can be determined by subtracting the length of the gap (firstGap)
      # from when the child first fixated on the other image (otherFixLoc)
      
      stringRT=names(fixations[otherFixLoc-firstGap])
      # convert the column (which is a string including the character F) into a numeric value
      RT = as.numeric(sub("F","",stringRT))
      
    }
    
    d$FirstGap[row]=firstGap
    d$RT[row]=RT
    
    print(paste("Sub",unique(d$Sub.Num),"trial",d$Tr.Num[row]))
    
  }
  return(d)
}



# Load, Format, Combine, Export data --------------------------------------

setwd(read_from)
codingFiles=list.files(pattern=identifier)

for (i in 1:length(codingFiles)) {
  
  d = read.csv(codingFiles[i],stringsAsFactors = FALSE,colClasses=c("character"))
  
  # recode any empty frames (which were pre-screened out and therefore not coded) as away
  # RON DO THIS
  
  # Add column indicating whether the child is looking at the Target (Accuracy=1), 
  # Distractor (Accuracy=0), or Away (Accuracy= - or . or ) 
  # at the onset of the target word (F0)
  d$Response = ifelse(d$F0==1, "T",ifelse(d$F0==0,"D","A"))
  
  # add columns indicating when children begain their first shift from one image to another (RT)
  # and how how many off/away frames occured during the shift (FirstGap)
  # calcRT function takes a data frame (here d), start window values (F0), and end window value
  # the end window value can be hard coded or auto-determined to be the final frame in the data frame
  # (i.e., the final colname)
  d = calcRT(d,"F0",colnames(d)[ncol(d)])
  
  # if this is the first child, create a new data frame,
  # otherwise append the data to the existing data frame
  if(i==1){
    e = d
  } else {
    # e = bind_rows(e,d)
    e = rbind(e,d)
  }

}

# reorder columns to match iCoder arrangement
r = e[,c(1:which(names(e)=="Condition"),which(names(e)=="Response"),which(names(e)=="FirstGap"),which(names(e)=="RT"),which(names(e)=="CritOnset"):(which(names(e)=="Response")-1))]

setwd(save_to)
write.csv(r,"CueCue_101_peyeData_wide_modified.csv",row.names=FALSE)


