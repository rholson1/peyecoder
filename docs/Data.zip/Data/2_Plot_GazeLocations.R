
# Load Raw Gaze Data ----------------------------------------------------------

setwd("~/Box Sync/peyeCoder/Data/tobii/")

# load the prior data
d <- dfReadDat("CueCue_GazeData_n55.txt")

d <- read.delim("CueCue_101_TobiiData.txt",stringsAsFactors = F)
d <- d[,-1]

# Plot Fixation Locations -------------------------------------------------

# sub.num='201'

# setwd("~/Box Sync/Dissertation/Analyses/GazeLocations/")


plotGazeLocation=function(plot,sub.num) {
  
  
  plot = d %>%
    filter(Sub.Num == sub.num)
  
  plot$AOI[is.na(plot$AOI)]='away'
  
  if (length(plot$Sub.Num!=0)){
    
    ## plot teaching fixations ##
    
    ggplot(plot[plot$Phase=='teaching',], aes(x=GazePointXMean, y=GazePointYMean,color=AOI)) +
      geom_point(stat='identity') +
      theme_bw(base_size=10) +
      coord_cartesian(xlim=c(0,1920),ylim = c(0,1080)) +
      scale_x_continuous(breaks=seq(from=0,to=1920,by=80))+
      # scale_color_manual(values=c('forestgreen','indianred2','grey')) +
      scale_y_reverse(lim=c(1080,0),breaks=seq(from=0,to=1080,by=60))+
      labs(x='X',y='Y',title='Teaching')+
      # left object
      geom_segment(aes(x=350, y=680, xend=790, yend=680),colour='black')+
      geom_segment(aes(x=350, y=1080, xend=790, yend=1080),colour='black') + 
      geom_segment(aes(x=350, y=680, xend=350, yend=1080),colour='black')+
      geom_segment(aes(x=790, y=680, xend=790, yend=1080),colour='black')+
      # right object
      geom_segment(aes(x=1310, y=680, xend=1750, yend=680),colour='black')+
      geom_segment(aes(x=1310, y=1080, xend=1750, yend=1080),colour='black') + 
      geom_segment(aes(x=1310, y=680, xend=1310, yend=1080),colour='black')+
      geom_segment(aes(x=1750, y=680, xend=1750, yend=1080),colour='black') +
      # face
      geom_segment(aes(x=880, y=350, xend=1130, yend=350),colour='black')+
      geom_segment(aes(x=880, y=740, xend=1130, yend=740),colour='black') + 
      geom_segment(aes(x=880, y=350, xend=880, yend=740),colour='black')+
      geom_segment(aes(x=1130, y=350, xend=1130, yend=740),colour='black') +
      scale_color_manual(values=c('gray','forestgreen','dodgerblue','coral2'))
    
    ggsave(paste('CueCue_GazeLoc_Teaching_sub',as.character(sub.num),'.pdf',sep=''),width=9,height=5,dpi=300)
    
    
    ## plot test fixations ##
    
    ggplot(plot[plot$Phase=='test',], aes(x=GazePointXMean, y=GazePointYMean,color=AOI)) +
      geom_point(stat='identity') +
      theme_bw(base_size=10) +
      coord_cartesian(xlim=c(0,1920),ylim = c(0,1080)) +
      scale_x_continuous(breaks=seq(from=0,to=1920,by=80))+
      # scale_color_manual(values=c('forestgreen','indianred2','grey')) +
      scale_y_reverse(lim=c(1080,0),breaks=seq(from=0,to=1080,by=60))+
      labs(x='X',y='Y',title='Test')+
      # left object
      geom_segment(aes(x=50, y=527, xend=700, yend=527),colour='black')+
      geom_segment(aes(x=50, y=1050, xend=700, yend=1050),colour='black') + 
      geom_segment(aes(x=50, y=527, xend=50, yend=1050),colour='black')+
      geom_segment(aes(x=700, y=527, xend=700, yend=1050),colour='black')+
      # right object
      geom_segment(aes(x=1220, y=527, xend=1870, yend=527),colour='black')+
      geom_segment(aes(x=1220, y=1050, xend=1870, yend=1050),colour='black') + 
      geom_segment(aes(x=1220, y=527, xend=1220, yend=1050),colour='black')+
      geom_segment(aes(x=1870, y=527, xend=1870, yend=1050),colour='black')+
      scale_color_manual(values=c('gray','dodgerblue','coral2'))
    
    ggsave(paste('CueCue_GazeLoc_Test_sub',as.character(sub.num),'.pdf',sep=''),width=9,height=5,dpi=300)
    
    
  }
}



# setwd("~/Box Sync/Dissertation/Analyses/GazeLocations/")

for (i in unique(d$Sub.Num)) {
  plotGazeLocation(d,i)
}

remove(d,i,plot,GazeLocation)

